// Fix for missing button functionality - Add this to the end of script.js

// Make functions globally accessible
window.tracker = tracker;
window.closeEditModal = () => tracker.closeEditModal();
window.generateDateReport = () => tracker.generateDateReport();
window.generateMonthReport = () => tracker.generateMonthReport();
window.generateYearReport = () => tracker.generateYearReport();

// Add sample expenses for testing
if (tracker.expenses.length === 0 && tracker.currentUser) {
    const sampleExpenses = [
        {
            id: '1',
            date: new Date().toISOString(),
            category: 'Food',
            description: 'Grocery shopping',
            amount: 85.50,
            userId: tracker.currentUser.id
        },
        {
            id: '2', 
            date: new Date(Date.now() - 86400000).toISOString(),
            category: 'Transport',
            description: 'Gas refill',
            amount: 45.00,
            userId: tracker.currentUser.id
        },
        {
            id: '3',
            date: new Date(Date.now() - 172800000).toISOString(),
            category: 'Entertainment',
            description: 'Movie tickets',
            amount: 25.00,
            userId: tracker.currentUser.id
        }
    ];
    
    tracker.expenses = sampleExpenses;
    tracker.saveExpenses();
    tracker.updateDashboard();
}
