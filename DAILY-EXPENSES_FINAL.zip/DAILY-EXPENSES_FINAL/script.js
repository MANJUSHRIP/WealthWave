// Expense Tracker JavaScript with Authentication
class ExpenseTracker {
    constructor() {
        this.currentUser = null;
        this.expenses = [];
        this.currentPage = 'dashboard';
        this.charts = {};
        this.eventListenersSetup = false;
        this.init();
    }

    init() {
        this.checkAuthentication();
        this.setupAuthEventListeners();
        if (this.currentUser) {
            this.loadUserExpenses();
            this.setupEventListeners();
            this.setCurrentDate();
            this.updateDashboard();
            this.showPage('dashboard');
        }
    }

    // Authentication System
    checkAuthentication() {
        const userData = localStorage.getItem('currentUser');
        if (userData) {
            this.currentUser = JSON.parse(userData);
            this.showApp();
        } else {
            this.showAuth();
        }
    }

    showAuth() {
        document.getElementById('authContainer').classList.remove('hidden');
        document.getElementById('appContainer').classList.add('hidden');
    }

    showApp() {
        document.getElementById('authContainer').classList.add('hidden');
        document.getElementById('appContainer').classList.remove('hidden');
        this.updateUserInfo();
        this.updateWelcomeUser();
        // Ensure event listeners are set up
        if (!this.eventListenersSetup) {
            this.setupEventListeners();
        }
        // Load expenses and show dashboard
        this.loadUserExpenses();
        this.setCurrentDate();
        this.updateDashboard();
        this.showPage('dashboard');
        // Initialize notification badge
        this.updateNotificationBadge();
    }

    setupAuthEventListeners() {
        // Use event delegation for auth forms
        document.body.addEventListener('submit', (e) => {
            if (e.target.id === 'loginForm') {
                e.preventDefault();
                this.handleLogin();
            } else if (e.target.id === 'signupForm') {
                e.preventDefault();
                this.handleSignup();
            }
        });

        // Auth toggle - use event delegation for dynamically created links
        document.body.addEventListener('click', (e) => {
            if (e.target.id === 'authToggleLink' || e.target.closest('#authToggleLink')) {
                e.preventDefault();
                this.toggleAuthForm();
            }
        });

        // Logout button - use event delegation
        document.body.addEventListener('click', (e) => {
            if (e.target.closest('#logoutBtn')) {
                e.preventDefault();
                this.handleLogout();
            }
        });
    }

    handleLogin() {
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;

        const users = this.getUsers();
        const user = users.find(u => u.email === email && u.password === password);

        if (user) {
            this.currentUser = user;
            localStorage.setItem('currentUser', JSON.stringify(user));
            this.showNotification('Login successful!', 'success');
            this.showApp();
            this.setupEventListeners();
            this.loadUserExpenses();
            this.setCurrentDate();
            this.updateDashboard();
            this.showPage('dashboard');
        } else {
            this.showNotification('Invalid email or password', 'error');
        }
    }

    handleSignup() {
        const name = document.getElementById('signupName').value;
        const gender = document.getElementById('signupGender').value;
        const email = document.getElementById('signupEmail').value;
        const password = document.getElementById('signupPassword').value;
        const confirmPassword = document.getElementById('signupConfirmPassword').value;

        if (password !== confirmPassword) {
            this.showNotification('Passwords do not match', 'error');
            return;
        }

        const users = this.getUsers();
        if (users.find(u => u.email === email)) {
            this.showNotification('Email already exists', 'error');
            return;
        }

        const newUser = {
            id: Date.now().toString(),
            name,
            gender,
            email,
            password,
            createdAt: new Date().toISOString()
        };

        users.push(newUser);
        localStorage.setItem('users', JSON.stringify(users));

        this.currentUser = newUser;
        localStorage.setItem('currentUser', JSON.stringify(newUser));
        
        this.showNotification('Account created successfully!', 'success');
        this.showApp();
        this.setupEventListeners();
        this.setCurrentDate();
        this.updateDashboard();
        this.showPage('dashboard');
    }

    handleLogout() {
        localStorage.removeItem('currentUser');
        this.currentUser = null;
        this.expenses = [];
        this.showNotification('Logged out successfully', 'success');
        this.showAuth();
        
        // Reset forms
        document.getElementById('loginForm').reset();
        document.getElementById('signupForm').reset();
    }

    toggleAuthForm() {
        const loginForm = document.getElementById('loginForm');
        const signupForm = document.getElementById('signupForm');
        const authTitle = document.getElementById('authTitle');
        const authSubtitle = document.getElementById('authSubtitle');
        const authToggleText = document.getElementById('authToggleText');
        const authToggleLink = document.getElementById('authToggleLink');

        if (loginForm.classList.contains('hidden')) {
            // Show login form
            loginForm.classList.remove('hidden');
            signupForm.classList.add('hidden');
            authTitle.textContent = 'Welcome Back';
            authSubtitle.textContent = 'Sign in to your account';
            authToggleText.innerHTML = "Don't have an account? <a href='#' id='authToggleLink'>Sign Up</a>";
        } else {
            // Show signup form
            loginForm.classList.add('hidden');
            signupForm.classList.remove('hidden');
            authTitle.textContent = 'Create Account';
            authSubtitle.textContent = 'Sign up to get started';
            authToggleText.innerHTML = "Already have an account? <a href='#' id='authToggleLink'>Sign In</a>";
        }

        // Event listener is handled by event delegation in setupAuthEventListeners
    }

    getUsers() {
        const users = localStorage.getItem('users');
        return users ? JSON.parse(users) : [];
    }

    updateUserInfo() {
        if (this.currentUser) {
            document.getElementById('userName').textContent = this.currentUser.name;
            document.getElementById('userEmail').textContent = this.currentUser.email;
            this.updateUserAvatar();
        }
    }

    updateUserAvatar() {
        const avatar = document.getElementById('userAvatar');
        if (this.currentUser.gender === 'male') {
            avatar.className = 'user-avatar male';
            avatar.innerHTML = '<i class="fas fa-male"></i>';
        } else if (this.currentUser.gender === 'female') {
            avatar.className = 'user-avatar female';
            avatar.innerHTML = '<i class="fas fa-female"></i>';
        } else {
            avatar.className = 'user-avatar';
            avatar.innerHTML = '<i class="fas fa-user"></i>';
        }
    }

    updateWelcomeUser() {
        if (this.currentUser) {
            document.getElementById('welcomeUserName').textContent = this.currentUser.name;
        }
    }

    // Data Management (User-specific)
    loadUserExpenses() {
        if (!this.currentUser) return;
        
        const userExpensesKey = `expenses_${this.currentUser.id}`;
        const stored = localStorage.getItem(userExpensesKey);
        this.expenses = stored ? JSON.parse(stored) : [];
    }

    saveExpenses() {
        if (!this.currentUser) return;
        
        const userExpensesKey = `expenses_${this.currentUser.id}`;
        localStorage.setItem(userExpensesKey, JSON.stringify(this.expenses));
    }

    addExpense(expense) {
        expense.id = Date.now().toString();
        expense.date = new Date(expense.date).toISOString();
        expense.userId = this.currentUser.id;
        this.expenses.push(expense);
        this.saveExpenses();
        this.updateDashboard();
        this.showNotification('Expense added successfully!', 'success');
        // Show category animation
        this.showCategoryAnimation(expense.category);
    }

    // Get category icon (Font Awesome)
    getCategoryIcon(category) {
        const categoryIcons = {
            'Food': 'fa-utensils',
            'Transport': 'fa-car',
            'Shopping': 'fa-shopping-bag',
            'Entertainment': 'fa-film',
            'Bills': 'fa-credit-card',
            'Healthcare': 'fa-heartbeat',
            'Education': 'fa-graduation-cap',
            'Other': 'fa-box'
        };
        return categoryIcons[category] || 'fa-tag';
    }

    // Get category emoji
    getCategoryEmoji(category) {
        const categoryImages = {
            'Food': '🍕',
            'Transport': '🚗',
            'Shopping': '🛍️',
            'Entertainment': '🎬',
            'Bills': '💳',
            'Healthcare': '🏥',
            'Education': '📚',
            'Other': '📦'
        };
        return categoryImages[category] || '💰';
    }

    // Get category color
    getCategoryColor(category) {
        const categoryColors = {
            'Food': '#ef4444',
            'Transport': '#3b82f6',
            'Shopping': '#8b5cf6',
            'Entertainment': '#ec4899',
            'Bills': '#f59e0b',
            'Healthcare': '#10b981',
            'Education': '#06b6d4',
            'Other': '#6b7280'
        };
        return categoryColors[category] || '#8b5cf6';
    }

    // Show category popup animation
    showCategoryAnimation(category) {
        const categoryEmoji = this.getCategoryEmoji(category);
        const categoryColor = this.getCategoryColor(category);

        // Create animation element
        const animElement = document.createElement('div');
        animElement.className = 'category-popup';
        animElement.innerHTML = `
            <div class="category-popup-content" style="border-color: ${categoryColor};">
                <div class="category-popup-emoji">${categoryEmoji}</div>
                <div class="category-popup-text">${category}</div>
            </div>
        `;
        animElement.style.setProperty('--category-color', categoryColor);
        
        document.body.appendChild(animElement);

        // Trigger animation
        setTimeout(() => {
            animElement.classList.add('active');
        }, 10);

        // Remove after animation
        setTimeout(() => {
            animElement.classList.add('fade-out');
            setTimeout(() => {
                if (animElement.parentNode) {
                    animElement.parentNode.removeChild(animElement);
                }
            }, 500);
        }, 2000);
    }

    updateExpense(id, updatedExpense) {
        const index = this.expenses.findIndex(exp => exp.id === id);
        if (index !== -1) {
            this.expenses[index] = { ...updatedExpense, id, userId: this.currentUser.id };
            this.expenses[index].date = new Date(updatedExpense.date).toISOString();
            this.saveExpenses();
            this.updateDashboard();
            this.showNotification('Expense updated successfully!', 'success');
        }
    }

    deleteExpense(id) {
        this.expenses = this.expenses.filter(exp => exp.id !== id);
        this.saveExpenses();
        this.updateDashboard();
        this.showNotification('Expense deleted successfully!', 'success');
    }

    // Event Listeners
    setupEventListeners() {
        // Use event delegation for navigation to avoid duplicate listeners
        const sidebarNav = document.querySelector('.sidebar-nav');
        if (!sidebarNav || this.eventListenersSetup) return;
        
        this.eventListenersSetup = true;
        
        // Single event delegation handler for all navigation clicks
        sidebarNav.addEventListener('click', (e) => {
            e.preventDefault();
            
            // Check for submenu link first (more specific)
            const submenuLink = e.target.closest('.submenu-link');
            if (submenuLink) {
                const submenuItem = submenuLink.closest('.submenu-item');
                if (submenuItem) {
                    const page = submenuItem.dataset.page;
                    if (page) {
                        this.showPage(page);
                        // Close submenu after navigation
                        const hasSubmenu = submenuItem.closest('.has-submenu');
                        if (hasSubmenu) {
                            hasSubmenu.classList.remove('expanded');
                        }
                    }
                }
                return;
            }
            
            // Check for regular nav link
            const navLink = e.target.closest('.nav-link');
            if (!navLink) return;
            
            const navItem = navLink.closest('.nav-item');
            if (!navItem) return;
            
            // Check if it's a submenu parent (has-submenu)
            if (navItem.classList.contains('has-submenu')) {
                // Toggle submenu expansion
                navItem.classList.toggle('expanded');
                return;
            }
            
            // Regular navigation item
            const page = navItem.dataset.page;
            if (page) {
                this.showPage(page);
            }
        });

        // Mobile menu toggle
        const menuToggle = document.querySelector('.menu-toggle');
        if (menuToggle) {
            menuToggle.addEventListener('click', () => {
                document.querySelector('.sidebar').classList.toggle('active');
            });
        }

        // Expense form - use event delegation for dynamic pages
        document.body.addEventListener('submit', (e) => {
            if (e.target.id === 'expenseForm') {
                e.preventDefault();
                this.handleAddExpense();
            } else if (e.target.id === 'editExpenseForm') {
                e.preventDefault();
                this.handleEditExpense();
            }
        });

        // Search and filters - use event delegation
        const managePage = document.getElementById('manage-expenses-page');
        if (managePage) {
            managePage.addEventListener('input', (e) => {
                if (e.target.id === 'expenseSearch') {
                    this.filterExpenses();
                }
            });
            managePage.addEventListener('change', (e) => {
                if (e.target.id === 'categoryFilter' || e.target.id === 'dateFilter') {
                    this.filterExpenses();
                }
            });
        }

        // Global search
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.globalSearch(e.target.value);
            });
            searchInput.addEventListener('focus', (e) => {
                if (e.target.value) {
                    this.showSearchPopup(e.target.value);
                }
            });
        }

        // Notification bell button
        const notificationBtn = document.querySelector('.notification-btn');
        if (notificationBtn) {
            notificationBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.toggleNotifications();
            });
        }

        // Close notification dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.notification-btn') && !e.target.closest('.notification-dropdown')) {
                this.closeNotifications();
            }
            // Close search popup when clicking outside
            if (!e.target.closest('#searchInput') && !e.target.closest('.search-popup') && !e.target.closest('.search-bar')) {
                this.hideSearchPopup();
            }
        });

        // Chart period buttons - use event delegation
        const dashboardPage = document.getElementById('dashboard-page');
        if (dashboardPage) {
            dashboardPage.addEventListener('click', (e) => {
                const btnAction = e.target.closest('.btn-action');
                if (btnAction) {
                    e.preventDefault();
                    document.querySelectorAll('.btn-action').forEach(btn => btn.classList.remove('active'));
                    btnAction.classList.add('active');
                    this.updateChartPeriod(btnAction.dataset.period);
                }
            });
        }

        // Support functionality
        const btnSend = document.querySelector('.btn-send');
        if (btnSend) {
            btnSend.addEventListener('click', () => {
                this.sendSupportMessage();
            });
        }

        const supportInput = document.querySelector('.support-input input');
        if (supportInput) {
            supportInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.sendSupportMessage();
                }
            });
        }

        // View All button
        const btnViewAll = document.querySelector('.btn-view-all');
        if (btnViewAll) {
            btnViewAll.addEventListener('click', () => {
                this.showPage('manage-expenses');
            });
        }
    }

    // Page Navigation
    showPage(pageName) {
        // Hide all pages
        document.querySelectorAll('.page').forEach(page => {
            page.classList.remove('active');
        });

        // Show selected page
        const targetPage = document.getElementById(`${pageName}-page`);
        if (targetPage) {
            targetPage.classList.add('active');
            targetPage.classList.remove('hidden'); // Remove hidden class if present
        }

        // Update navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });

        const activeNavItem = document.querySelector(`[data-page="${pageName}"]`);
        if (activeNavItem) {
            activeNavItem.classList.add('active');
        }

        // Update page title
        const pageTitle = document.querySelector('.page-title');
        if (pageTitle) {
            pageTitle.textContent = this.getPageTitle(pageName);
        }

        this.currentPage = pageName;

        // Page-specific initialization
        this.initPage(pageName);
    }

    getPageTitle(pageName) {
        const titles = {
            'dashboard': 'Dashboard',
            'add-expense': 'Add Expense',
            'manage-expenses': 'Manage Expenses',
            'expense-reports': 'Expense Reports',
            'date-reports': 'Date-wise Reports',
            'month-reports': 'Month-wise Reports',
            'year-reports': 'Year-wise Reports'
        };
        return titles[pageName] || 'Dashboard';
    }

    initPage(pageName) {
        switch (pageName) {
            case 'dashboard':
                this.updateDashboard();
                this.initCharts();
                break;
            case 'add-expense':
                this.setCurrentDate();
                break;
            case 'manage-expenses':
                this.loadUserExpenses();
                this.displayAllExpenses();
                break;
            case 'expense-reports':
                this.loadUserExpenses();
                this.generateExpenseReports();
                break;
            case 'date-reports':
                this.loadUserExpenses();
                break;
            case 'month-reports':
                this.loadUserExpenses();
                break;
            case 'year-reports':
                this.loadUserExpenses();
                break;
        }
    }

    // Dashboard
    updateDashboard() {
        this.updateStats();
        this.displayRecentExpenses();
        this.updateWelcomeMessages();
        if (this.currentPage === 'dashboard') {
            this.updateCharts();
        }
    }

    // Update welcome messages dynamically
    updateWelcomeMessages() {
        const messageList = document.querySelector('.message-list');
        if (!messageList) return;

        const totalExpenses = this.calculateTotalExpenses();
        const todayExpenses = this.calculateTodayExpenses();
        const recentExpenses = this.expenses
            .sort((a, b) => new Date(b.date) - new Date(a.date))
            .slice(0, 3);

        const messages = [];

        // Budget alert message
        if (totalExpenses > 0) {
            const avgDaily = totalExpenses / Math.max(1, this.expenses.length);
            if (todayExpenses > avgDaily * 1.5) {
                messages.push({
                    icon: 'fa-exclamation-triangle',
                    text: `Budget alert: You've spent ${this.formatCurrency(todayExpenses)} today, which is above your average`,
                    time: 'Just now'
                });
            }
        }

        // Recent expense messages
        if (recentExpenses.length > 0) {
            const latest = recentExpenses[0];
            messages.push({
                icon: 'fa-check-circle',
                text: `Recent expense: ${latest.description} - ${this.formatCurrency(latest.amount)}`,
                time: this.getRelativeTime(latest.date)
            });
        }

        // Weekly comparison
        const weekExpenses = this.calculateWeekExpenses();
        const lastWeekExpenses = this.calculateLastWeekExpenses();
        if (weekExpenses > 0 && lastWeekExpenses > 0) {
            const change = ((weekExpenses - lastWeekExpenses) / lastWeekExpenses * 100).toFixed(1);
            if (Math.abs(change) > 5) {
                messages.push({
                    icon: change > 0 ? 'fa-arrow-up' : 'fa-arrow-down',
                    text: `Your expenses ${change > 0 ? 'increased' : 'decreased'} by ${Math.abs(change)}% this week`,
                    time: '1 day ago'
                });
            }
        }

        // Default messages if no custom ones
        if (messages.length === 0) {
            messages.push(
                {
                    icon: 'fa-bell',
                    text: 'Welcome! Start tracking your expenses to see insights here.',
                    time: 'Just now'
                },
                {
                    icon: 'fa-chart-line',
                    text: 'Add your first expense to see spending trends and reports.',
                    time: '1 hour ago'
                }
            );
        }

        // Update message list
        messageList.innerHTML = messages.slice(0, 2).map(msg => `
            <div class="message-item">
                <div class="message-avatar">
                    <i class="fas ${msg.icon}"></i>
                </div>
                <div class="message-content">
                    <p>${msg.text}</p>
                    <span class="message-time">${msg.time}</span>
                </div>
            </div>
        `).join('');
    }

    calculateWeekExpenses() {
        const weekAgo = new Date();
        weekAgo.setDate(weekAgo.getDate() - 7);
        return this.expenses
            .filter(expense => new Date(expense.date) >= weekAgo)
            .reduce((total, expense) => total + parseFloat(expense.amount), 0);
    }

    calculateLastWeekExpenses() {
        const twoWeeksAgo = new Date();
        twoWeeksAgo.setDate(twoWeeksAgo.getDate() - 14);
        const weekAgo = new Date();
        weekAgo.setDate(weekAgo.getDate() - 7);
        return this.expenses
            .filter(expense => {
                const date = new Date(expense.date);
                return date >= twoWeeksAgo && date < weekAgo;
            })
            .reduce((total, expense) => total + parseFloat(expense.amount), 0);
    }

    getRelativeTime(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const diffMs = now - date;
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMs / 3600000);
        const diffDays = Math.floor(diffMs / 86400000);

        if (diffMins < 1) return 'Just now';
        if (diffMins < 60) return `${diffMins} minute${diffMins !== 1 ? 's' : ''} ago`;
        if (diffHours < 24) return `${diffHours} hour${diffHours !== 1 ? 's' : ''} ago`;
        if (diffDays < 7) return `${diffDays} day${diffDays !== 1 ? 's' : ''} ago`;
        return this.formatDate(dateString);
    }

    updateStats() {
        const totalExpenses = this.calculateTotalExpenses();
        const todayExpenses = this.calculateTodayExpenses();
        const categories = this.getUniqueCategories();
        const transactions = this.expenses.length;

        document.getElementById('totalExpenses').textContent = this.formatCurrency(totalExpenses);
        document.getElementById('todayExpenses').textContent = this.formatCurrency(todayExpenses);
        document.getElementById('categoryCount').textContent = categories.length;
        document.getElementById('transactionCount').textContent = transactions;
        
        // Update notification badge when stats change
        this.updateNotificationBadge();
    }

    calculateTotalExpenses() {
        return this.expenses.reduce((total, expense) => total + parseFloat(expense.amount), 0);
    }

    calculateTodayExpenses() {
        const today = new Date().toDateString();
        return this.expenses
            .filter(expense => new Date(expense.date).toDateString() === today)
            .reduce((total, expense) => total + parseFloat(expense.amount), 0);
    }

    getUniqueCategories() {
        return [...new Set(this.expenses.map(expense => expense.category))];
    }

    displayRecentExpenses() {
        const tbody = document.getElementById('recentTransactionsTable');
        const recentExpenses = this.expenses
            .sort((a, b) => new Date(b.date) - new Date(a.date))
            .slice(0, 5);

        if (recentExpenses.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="no-data">No transactions yet</td></tr>';
            return;
        }

        tbody.innerHTML = recentExpenses.map((expense, index) => {
            const categoryIcon = this.getCategoryIcon(expense.category);
            const categoryColor = this.getCategoryColor(expense.category);
            return `
            <tr class="table-row-animate" style="animation-delay: ${index * 0.1}s;">
                <td>
                    <span class="category-badge" style="--category-color: ${categoryColor};">
                        <i class="fas ${categoryIcon}"></i>
                        <span>${expense.category}</span>
                    </span>
                </td>
                <td>${expense.description}</td>
                <td><strong>${this.formatCurrency(expense.amount)}</strong></td>
                <td>${this.formatDate(expense.date)}</td>
                <td><span class="status-badge completed">Completed</span></td>
            </tr>
        `;
        }).join('');
    }

    // Charts
    initCharts() {
        this.initExpenseTrendChart();
        this.initCategoryChart();
    }

    initExpenseTrendChart() {
        const ctx = document.getElementById('expenseTrendChart');
        if (!ctx) return;

        if (this.charts.expenseTrend) {
            this.charts.expenseTrend.destroy();
        }

        const last7Days = this.getLast7Days();
        const currentYear = new Date().getFullYear();
        const lastYear = currentYear - 1;
        
        // Current period data
        const currentData = last7Days.map(date => {
            const dayExpenses = this.expenses.filter(expense => {
                const expenseDate = new Date(expense.date);
                return expenseDate.toDateString() === date.toDateString() && 
                       expenseDate.getFullYear() === currentYear;
            });
            return dayExpenses.reduce((total, expense) => total + parseFloat(expense.amount), 0);
        });

        // Previous period data (for comparison - simulated or from last year)
        const previousData = last7Days.map(date => {
            const dayExpenses = this.expenses.filter(expense => {
                const expenseDate = new Date(expense.date);
                const prevDate = new Date(date);
                prevDate.setFullYear(lastYear);
                return expenseDate.toDateString() === prevDate.toDateString();
            });
            return dayExpenses.reduce((total, expense) => total + parseFloat(expense.amount), 0);
        });

        const chartContext = ctx.getContext('2d');
        
        // Create gradients for both datasets
        const gradient1 = chartContext.createLinearGradient(0, 0, 0, 400);
        gradient1.addColorStop(0, 'rgba(16, 185, 129, 0.4)'); // Green
        gradient1.addColorStop(1, 'rgba(16, 185, 129, 0.05)');
        
        const gradient2 = chartContext.createLinearGradient(0, 0, 0, 400);
        gradient2.addColorStop(0, 'rgba(59, 130, 246, 0.4)'); // Blue
        gradient2.addColorStop(1, 'rgba(59, 130, 246, 0.05)');

        this.charts.expenseTrend = new Chart(ctx, {
            type: 'line',
            data: {
                labels: last7Days.map(date => date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })),
                datasets: [
                    {
                        label: `${currentYear} Expenses`,
                        data: currentData,
                        borderColor: '#10b981',
                        backgroundColor: gradient1,
                        borderWidth: 3,
                        pointBackgroundColor: '#10b981',
                        pointBorderColor: '#ffffff',
                        pointBorderWidth: 2,
                        pointRadius: 5,
                        pointHoverRadius: 7,
                        pointHoverBackgroundColor: '#059669',
                        pointHoverBorderColor: '#ffffff',
                        tension: 0.4,
                        fill: true,
                        animation: {
                            duration: 2000,
                            easing: 'easeInOutQuart'
                        }
                    },
                    {
                        label: `${lastYear} Expenses`,
                        data: previousData,
                        borderColor: '#3b82f6',
                        backgroundColor: gradient2,
                        borderWidth: 3,
                        pointBackgroundColor: '#3b82f6',
                        pointBorderColor: '#ffffff',
                        pointBorderWidth: 2,
                        pointRadius: 5,
                        pointHoverRadius: 7,
                        pointHoverBackgroundColor: '#2563eb',
                        pointHoverBorderColor: '#ffffff',
                        tension: 0.4,
                        fill: true,
                        animation: {
                            duration: 2000,
                            easing: 'easeInOutQuart'
                        }
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                        align: 'end',
                        labels: {
                            usePointStyle: true,
                            pointStyle: 'circle',
                            padding: 15,
                            font: {
                                size: 12,
                                weight: '500'
                            },
                            color: '#64748b'
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        padding: 12,
                        titleFont: {
                            size: 14,
                            weight: 'bold'
                        },
                        bodyFont: {
                            size: 13
                        },
                        borderColor: '#8b5cf6',
                        borderWidth: 2,
                        cornerRadius: 8,
                        displayColors: false,
                        callbacks: {
                            label: (context) => {
                                return `Amount: ${this.formatCurrency(context.parsed.y)}`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#64748b',
                            font: {
                                size: 11
                            }
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(226, 232, 240, 0.5)',
                            drawBorder: false
                        },
                        ticks: {
                            color: '#64748b',
                            font: {
                                size: 11
                            },
                            callback: (value) => {
                                return '₹' + value.toFixed(0);
                            }
                        }
                    }
                },
                animation: {
                    duration: 1500,
                    easing: 'easeInOutQuart'
                }
            }
        });
    }

    initCategoryChart() {
        const ctx = document.getElementById('categoryChart');
        if (!ctx) return;

        if (this.charts.category) {
            this.charts.category.destroy();
        }

        const categoryData = this.getCategoryData();
        
        // Beautiful gradient colors for categories
        const categoryColors = [
            'rgba(239, 68, 68, 0.8)',      // Red - Food
            'rgba(59, 130, 246, 0.8)',    // Blue - Transport
            'rgba(139, 92, 246, 0.8)',    // Purple - Shopping
            'rgba(236, 72, 153, 0.8)',   // Pink - Entertainment
            'rgba(245, 158, 11, 0.8)',    // Orange - Bills
            'rgba(16, 185, 129, 0.8)',    // Green - Healthcare
            'rgba(6, 182, 212, 0.8)',     // Cyan - Education
            'rgba(107, 114, 128, 0.8)'    // Gray - Other
        ];
        
        const categoryHoverColors = [
            'rgba(239, 68, 68, 1)',
            'rgba(59, 130, 246, 1)',
            'rgba(139, 92, 246, 1)',
            'rgba(236, 72, 153, 1)',
            'rgba(245, 158, 11, 1)',
            'rgba(16, 185, 129, 1)',
            'rgba(6, 182, 212, 1)',
            'rgba(107, 114, 128, 1)'
        ];
        
        this.charts.category = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: Object.keys(categoryData),
                datasets: [{
                    data: Object.values(categoryData),
                    backgroundColor: categoryColors.slice(0, Object.keys(categoryData).length),
                    borderColor: '#ffffff',
                    borderWidth: 3,
                    hoverBackgroundColor: categoryHoverColors.slice(0, Object.keys(categoryData).length),
                    hoverBorderColor: '#ffffff',
                    hoverBorderWidth: 4
                }]
            },
            options: {
                responsive: true,
                cutout: '60%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 15,
                            usePointStyle: true,
                            pointStyle: 'circle',
                            font: {
                                size: 12,
                                weight: '500'
                            },
                            color: '#64748b'
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        padding: 12,
                        titleFont: {
                            size: 14,
                            weight: 'bold'
                        },
                        bodyFont: {
                            size: 13
                        },
                        borderColor: '#8b5cf6',
                        borderWidth: 2,
                        cornerRadius: 8,
                        callbacks: {
                            label: (context) => {
                                const label = context.label || '';
                                const value = context.parsed || 0;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((value / total) * 100).toFixed(1);
                                return `${label}: ${this.formatCurrency(value)} (${percentage}%)`;
                            }
                        }
                    }
                },
                animation: {
                    animateRotate: true,
                    animateScale: true,
                    duration: 2000,
                    easing: 'easeInOutQuart'
                },
                interaction: {
                    intersect: false
                }
            }
        });
    }

    updateCharts() {
        if (this.charts.expense) {
            this.initExpenseChart();
        }
        if (this.charts.category) {
            this.initCategoryChart();
        }
    }

    getCategoryData() {
        const categoryData = {};
        this.expenses.forEach(expense => {
            if (!categoryData[expense.category]) {
                categoryData[expense.category] = 0;
            }
            categoryData[expense.category] += parseFloat(expense.amount);
        });
        return categoryData;
    }

    getLast7Days() {
        const dates = [];
        for (let i = 6; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            dates.push(date);
        }
        return dates;
    }

    // Expense Management
    handleAddExpense() {
        const form = document.getElementById('expenseForm');
        if (!form) {
            console.error('Expense form not found');
            return;
        }

        const date = document.getElementById('expenseDate').value;
        const category = document.getElementById('expenseCategory').value;
        const description = document.getElementById('expenseDescription').value;
        const amount = parseFloat(document.getElementById('expenseAmount').value);

        if (!date || !category || !description || !amount || isNaN(amount)) {
            this.showNotification('Please fill in all fields correctly', 'error');
            return;
        }

        const expense = {
            date: date,
            category: category,
            description: description,
            amount: amount
        };

        this.addExpense(expense);
        form.reset();
        this.setCurrentDate(); // Reset date to today
        this.showPage('dashboard');
    }

    editExpense(id) {
        const expense = this.expenses.find(exp => exp.id === id);
        if (!expense) return;

        document.getElementById('editExpenseId').value = expense.id;
        document.getElementById('editExpenseDate').value = new Date(expense.date).toISOString().split('T')[0];
        document.getElementById('editExpenseCategory').value = expense.category;
        document.getElementById('editExpenseDescription').value = expense.description;
        document.getElementById('editExpenseAmount').value = expense.amount;

        document.getElementById('editModal').classList.add('active');
    }

    handleEditExpense() {
        const idInput = document.getElementById('editExpenseId');
        if (!idInput) {
            console.error('Edit expense form not found');
            return;
        }

        const id = idInput.value;
        const date = document.getElementById('editExpenseDate').value;
        const category = document.getElementById('editExpenseCategory').value;
        const description = document.getElementById('editExpenseDescription').value;
        const amount = parseFloat(document.getElementById('editExpenseAmount').value);

        if (!date || !category || !description || !amount || isNaN(amount)) {
            this.showNotification('Please fill in all fields correctly', 'error');
            return;
        }

        const updatedExpense = {
            date: date,
            category: category,
            description: description,
            amount: amount
        };

        this.updateExpense(id, updatedExpense);
        this.closeEditModal();
    }

    deleteExpenseById(id) {
        if (confirm('Are you sure you want to delete this expense?')) {
            this.deleteExpense(id);
        }
    }

    closeEditModal() {
        document.getElementById('editModal').classList.remove('active');
    }

    // Manage Expenses
    displayAllExpenses() {
        const tbody = document.getElementById('allExpensesTable');
        const filteredExpenses = this.getFilteredExpenses();

        if (filteredExpenses.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="no-data">No expenses found</td></tr>';
            return;
        }

        tbody.innerHTML = filteredExpenses.map((expense, index) => {
            const categoryIcon = this.getCategoryIcon(expense.category);
            const categoryColor = this.getCategoryColor(expense.category);
            return `
            <tr class="table-row-animate" style="animation-delay: ${index * 0.05}s;">
                <td>${this.formatDate(expense.date)}</td>
                <td>
                    <span class="category-badge" style="--category-color: ${categoryColor};">
                        <i class="fas ${categoryIcon}"></i>
                        <span>${expense.category}</span>
                    </span>
                </td>
                <td>${expense.description}</td>
                <td><strong>${this.formatCurrency(expense.amount)}</strong></td>
                <td>
                    <button class="btn btn-sm btn-primary" onclick="tracker.editExpense('${expense.id}')">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="tracker.deleteExpenseById('${expense.id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `;
        }).join('');
    }

    getFilteredExpenses() {
        let filtered = [...this.expenses];

        // Search filter
        const searchTerm = document.getElementById('expenseSearch').value.toLowerCase();
        if (searchTerm) {
            filtered = filtered.filter(expense => 
                expense.description.toLowerCase().includes(searchTerm) ||
                expense.category.toLowerCase().includes(searchTerm)
            );
        }

        // Category filter
        const categoryFilter = document.getElementById('categoryFilter').value;
        if (categoryFilter) {
            filtered = filtered.filter(expense => expense.category === categoryFilter);
        }

        // Date filter
        const dateFilter = document.getElementById('dateFilter').value;
        if (dateFilter) {
            filtered = filtered.filter(expense => 
                new Date(expense.date).toDateString() === new Date(dateFilter).toDateString()
            );
        }

        return filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
    }

    filterExpenses() {
        this.displayAllExpenses();
    }

    // Reports
    generateExpenseReports() {
        const totalExpenses = this.calculateTotalExpenses();
        const avgDaily = this.calculateAverageDaily();
        const highestCategory = this.getHighestSpendingCategory();

        document.getElementById('reportTotalExpenses').textContent = this.formatCurrency(totalExpenses);
        document.getElementById('reportAvgDaily').textContent = this.formatCurrency(avgDaily);
        document.getElementById('reportHighestCategory').textContent = highestCategory;

        this.generateReportsChart();
    }

    calculateAverageDaily() {
        if (this.expenses.length === 0) return 0;
        
        const dates = [...new Set(this.expenses.map(expense => 
            new Date(expense.date).toDateString()
        ))];
        
        return this.calculateTotalExpenses() / dates.length;
    }

    getHighestSpendingCategory() {
        const categoryData = this.getCategoryData();
        let highestCategory = '-';
        let highestAmount = 0;

        Object.entries(categoryData).forEach(([category, amount]) => {
            if (amount > highestAmount) {
                highestAmount = amount;
                highestCategory = category;
            }
        });

        return highestCategory;
    }

    generateReportsChart() {
        const ctx = document.getElementById('reportsChart');
        if (!ctx) return;

        if (this.charts.reports) {
            this.charts.reports.destroy();
        }

        const monthlyData = this.getMonthlyData();
        const months = Object.keys(monthlyData);
        const values = Object.values(monthlyData);
        
        // Create gradient for each bar
        const chartContext = ctx.getContext('2d');
        const gradients = values.map((_, index) => {
            const gradient = chartContext.createLinearGradient(0, 0, 0, 400);
            const colors = [
                ['rgba(139, 92, 246, 0.8)', 'rgba(139, 92, 246, 1)'], // Purple
                ['rgba(59, 130, 246, 0.8)', 'rgba(59, 130, 246, 1)'], // Blue
                ['rgba(236, 72, 153, 0.8)', 'rgba(236, 72, 153, 1)'], // Pink
                ['rgba(245, 158, 11, 0.8)', 'rgba(245, 158, 11, 1)'], // Orange
                ['rgba(16, 185, 129, 0.8)', 'rgba(16, 185, 129, 1)'], // Green
                ['rgba(6, 182, 212, 0.8)', 'rgba(6, 182, 212, 1)']  // Cyan
            ];
            const colorPair = colors[index % colors.length];
            gradient.addColorStop(0, colorPair[0]);
            gradient.addColorStop(1, colorPair[1]);
            return gradient;
        });
        
        this.charts.reports = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: months,
                datasets: [{
                    label: 'Monthly Expenses',
                    data: values,
                    backgroundColor: gradients,
                    borderColor: gradients.map(g => {
                        // Extract color from gradient (approximate)
                        return '#8b5cf6';
                    }),
                    borderWidth: 2,
                    borderRadius: 8,
                    borderSkipped: false,
                    barThickness: 'flex',
                    maxBarThickness: 60
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        padding: 12,
                        titleFont: {
                            size: 14,
                            weight: 'bold'
                        },
                        bodyFont: {
                            size: 13
                        },
                        borderColor: '#8b5cf6',
                        borderWidth: 2,
                        cornerRadius: 8,
                        displayColors: true,
                        callbacks: {
                            label: (context) => {
                                return `Amount: ${this.formatCurrency(context.parsed.y)}`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#64748b',
                            font: {
                                size: 11
                            }
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(226, 232, 240, 0.5)',
                            drawBorder: false
                        },
                        ticks: {
                            color: '#64748b',
                            font: {
                                size: 11
                            },
                            callback: (value) => {
                                return '₹' + value.toFixed(0);
                            }
                        }
                    }
                },
                animation: {
                    duration: 1500,
                    easing: 'easeInOutQuart',
                    onComplete: () => {
                        // Add subtle animation effect
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });
    }

    getMonthlyData() {
        const monthlyData = {};
        this.expenses.forEach(expense => {
            const month = new Date(expense.date).toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
            if (!monthlyData[month]) {
                monthlyData[month] = 0;
            }
            monthlyData[month] += parseFloat(expense.amount);
        });
        return monthlyData;
    }

    // Date-wise Reports
    generateDateReport() {
        const startDate = new Date(document.getElementById('dateReportStart').value);
        const endDate = new Date(document.getElementById('dateReportEnd').value);
        
        if (!startDate || !endDate || startDate > endDate) {
            this.showNotification('Please select valid date range', 'error');
            return;
        }

        const filteredExpenses = this.expenses.filter(expense => {
            const expenseDate = new Date(expense.date);
            return expenseDate >= startDate && expenseDate <= endDate;
        });

        this.displayDateReport(filteredExpenses, startDate, endDate);
    }

    displayDateReport(expenses, startDate, endDate) {
        const content = document.getElementById('dateReportContent');
        const total = expenses.reduce((sum, exp) => sum + parseFloat(exp.amount), 0);
        
        let html = `
            <div class="report-summary">
                <h3>Report from ${this.formatDate(startDate)} to ${this.formatDate(endDate)}</h3>
                <p>Total Expenses: ${this.formatCurrency(total)}</p>
                <p>Number of Transactions: ${expenses.length}</p>
            </div>
            <div class="expense-table-container">
                <table class="expense-table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Category</th>
                            <th>Description</th>
                            <th>Amount</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        if (expenses.length === 0) {
            html += '<tr><td colspan="4" class="no-data">No expenses found in this period</td></tr>';
        } else {
            expenses.sort((a, b) => new Date(b.date) - new Date(a.date)).forEach((expense, index) => {
                const categoryIcon = this.getCategoryIcon(expense.category);
                const categoryColor = this.getCategoryColor(expense.category);
                html += `
                    <tr class="table-row-animate" style="animation-delay: ${index * 0.05}s;">
                        <td>${this.formatDate(expense.date)}</td>
                        <td>
                            <span class="category-badge" style="--category-color: ${categoryColor};">
                                <i class="fas ${categoryIcon}"></i>
                                <span>${expense.category}</span>
                            </span>
                        </td>
                        <td>${expense.description}</td>
                        <td><strong>${this.formatCurrency(expense.amount)}</strong></td>
                    </tr>
                `;
            });
        }

        html += '</tbody></table></div>';
        content.innerHTML = html;
    }

    // Month-wise Reports
    generateMonthReport() {
        const month = parseInt(document.getElementById('monthReportMonth').value);
        const year = parseInt(document.getElementById('monthReportYear').value);
        
        const filteredExpenses = this.expenses.filter(expense => {
            const expenseDate = new Date(expense.date);
            return expenseDate.getMonth() + 1 === month && expenseDate.getFullYear() === year;
        });

        this.displayMonthReport(filteredExpenses, month, year);
    }

    displayMonthReport(expenses, month, year) {
        const content = document.getElementById('monthReportContent');
        const monthName = new Date(year, month - 1).toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
        const total = expenses.reduce((sum, exp) => sum + parseFloat(exp.amount), 0);
        
        let html = `
            <div class="report-summary">
                <h3>Report for ${monthName}</h3>
                <p>Total Expenses: ${this.formatCurrency(total)}</p>
                <p>Number of Transactions: ${expenses.length}</p>
                <p>Daily Average: ${this.formatCurrency(total / new Date(year, month, 0).getDate())}</p>
            </div>
            <div class="expense-table-container">
                <table class="expense-table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Category</th>
                            <th>Description</th>
                            <th>Amount</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        if (expenses.length === 0) {
            html += '<tr><td colspan="4" class="no-data">No expenses found in this month</td></tr>';
        } else {
            expenses.sort((a, b) => new Date(b.date) - new Date(a.date)).forEach((expense, index) => {
                const categoryIcon = this.getCategoryIcon(expense.category);
                const categoryColor = this.getCategoryColor(expense.category);
                html += `
                    <tr class="table-row-animate" style="animation-delay: ${index * 0.05}s;">
                        <td>${this.formatDate(expense.date)}</td>
                        <td>
                            <span class="category-badge" style="--category-color: ${categoryColor};">
                                <i class="fas ${categoryIcon}"></i>
                                <span>${expense.category}</span>
                            </span>
                        </td>
                        <td>${expense.description}</td>
                        <td><strong>${this.formatCurrency(expense.amount)}</strong></td>
                    </tr>
                `;
            });
        }

        html += '</tbody></table></div>';
        content.innerHTML = html;
    }

    // Year-wise Reports
    generateYearReport() {
        const year = parseInt(document.getElementById('yearReportYear').value);
        
        const filteredExpenses = this.expenses.filter(expense => {
            const expenseDate = new Date(expense.date);
            return expenseDate.getFullYear() === year;
        });

        this.displayYearReport(filteredExpenses, year);
    }

    displayYearReport(expenses, year) {
        const content = document.getElementById('yearReportContent');
        const total = expenses.reduce((sum, exp) => sum + parseFloat(exp.amount), 0);
        
        let html = `
            <div class="report-summary">
                <h3>Report for ${year}</h3>
                <p>Total Expenses: ${this.formatCurrency(total)}</p>
                <p>Number of Transactions: ${expenses.length}</p>
                <p>Monthly Average: ${this.formatCurrency(total / 12)}</p>
            </div>
            <div class="expense-table-container">
                <table class="expense-table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Category</th>
                            <th>Description</th>
                            <th>Amount</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        if (expenses.length === 0) {
            html += '<tr><td colspan="4" class="no-data">No expenses found in this year</td></tr>';
        } else {
            expenses.sort((a, b) => new Date(b.date) - new Date(a.date)).forEach((expense, index) => {
                const categoryIcon = this.getCategoryIcon(expense.category);
                const categoryColor = this.getCategoryColor(expense.category);
                html += `
                    <tr class="table-row-animate" style="animation-delay: ${index * 0.05}s;">
                        <td>${this.formatDate(expense.date)}</td>
                        <td>
                            <span class="category-badge" style="--category-color: ${categoryColor};">
                                <i class="fas ${categoryIcon}"></i>
                                <span>${expense.category}</span>
                            </span>
                        </td>
                        <td>${expense.description}</td>
                        <td><strong>${this.formatCurrency(expense.amount)}</strong></td>
                    </tr>
                `;
            });
        }

        html += '</tbody></table></div>';
        content.innerHTML = html;
    }

    // Global Search
    globalSearch(query) {
        if (!query) {
            this.hideSearchPopup();
            if (this.currentPage === 'dashboard') {
                this.updateDashboard();
            }
            return;
        }

        this.showSearchPopup(query);
    }

    // Show search popup with results
    showSearchPopup(query) {
        const results = this.expenses.filter(expense => 
            expense.description.toLowerCase().includes(query.toLowerCase()) ||
            expense.category.toLowerCase().includes(query.toLowerCase())
        );

        // Remove existing popup if any
        const existingPopup = document.getElementById('searchPopup');
        if (existingPopup) {
            existingPopup.remove();
        }

        // Create popup container
        const popup = document.createElement('div');
        popup.id = 'searchPopup';
        popup.className = 'search-popup';
        
        if (results.length === 0) {
            popup.innerHTML = `
                <div class="search-popup-header">
                    <h4>Search Results</h4>
                    <button class="search-popup-close" onclick="tracker.hideSearchPopup()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="search-popup-content">
                    <div class="no-results">
                        <i class="fas fa-search"></i>
                        <p>No expenses found matching "${this.escapeHtml(query)}"</p>
                    </div>
                </div>
            `;
        } else {
            popup.innerHTML = `
                <div class="search-popup-header">
                    <h4>Search Results (${results.length})</h4>
                    <button class="search-popup-close" onclick="tracker.hideSearchPopup()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="search-popup-content">
                    <div class="search-results-list">
                        ${results.map(expense => {
                            const categoryIcon = this.getCategoryIcon(expense.category);
                            const categoryColor = this.getCategoryColor(expense.category);
                            const highlightedDescription = this.highlightSearchTerm(expense.description, query);
                            const highlightedCategory = this.highlightSearchTerm(expense.category, query);
                            return `
                                <div class="search-result-item" onclick="tracker.goToExpense('${expense.id}')">
                                    <div class="search-result-icon" style="background-color: ${categoryColor}20; color: ${categoryColor};">
                                        <i class="fas ${categoryIcon}"></i>
                                    </div>
                                    <div class="search-result-details">
                                        <div class="search-result-title">${highlightedDescription}</div>
                                        <div class="search-result-meta">
                                            <span class="search-result-category">${highlightedCategory}</span>
                                            <span class="search-result-date">${this.formatDate(expense.date)}</span>
                                            <span class="search-result-amount">${this.formatCurrency(expense.amount)}</span>
                                        </div>
                                    </div>
                                </div>
                            `;
                        }).join('')}
                    </div>
                </div>
            `;
        }

        // Position popup below search bar
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            const rect = searchInput.getBoundingClientRect();
            popup.style.top = `${rect.bottom + 10}px`;
            popup.style.left = `${rect.left}px`;
            popup.style.width = `${Math.max(rect.width, 400)}px`;
        }

        document.body.appendChild(popup);

        // Close on escape key
        const closeOnEscape = (e) => {
            if (e.key === 'Escape') {
                this.hideSearchPopup();
                document.removeEventListener('keydown', closeOnEscape);
            }
        };
        document.addEventListener('keydown', closeOnEscape);
    }

    // Hide search popup
    hideSearchPopup() {
        const popup = document.getElementById('searchPopup');
        if (popup) {
            popup.remove();
        }
    }

    // Highlight search term in text
    highlightSearchTerm(text, term) {
        if (!term) return this.escapeHtml(text);
        const regex = new RegExp(`(${this.escapeRegex(term)})`, 'gi');
        return this.escapeHtml(text).replace(regex, '<mark class="search-highlight">$1</mark>');
    }

    // Escape regex special characters
    escapeRegex(str) {
        return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    // Navigate to expense when clicking search result
    goToExpense(expenseId) {
        this.hideSearchPopup();
        this.showPage('manage-expenses');
        // Scroll to and highlight the expense
        setTimeout(() => {
            this.displayAllExpenses();
            // Find the expense row and scroll to it
            const expense = this.expenses.find(e => e.id === expenseId);
            if (expense) {
                // Clear search input
                const searchInput = document.getElementById('searchInput');
                if (searchInput) {
                    searchInput.value = '';
                }
            }
        }, 100);
    }

    // Notification dropdown functionality
    toggleNotifications() {
        const dropdown = document.getElementById('notificationDropdown');
        if (dropdown) {
            dropdown.classList.toggle('active');
            this.updateNotificationBadge();
        } else {
            this.createNotificationDropdown();
        }
    }

    closeNotifications() {
        const dropdown = document.getElementById('notificationDropdown');
        if (dropdown) {
            dropdown.classList.remove('active');
        }
    }

    createNotificationDropdown() {
        // Remove existing dropdown if any
        const existing = document.getElementById('notificationDropdown');
        if (existing) {
            existing.remove();
        }

        const dropdown = document.createElement('div');
        dropdown.id = 'notificationDropdown';
        dropdown.className = 'notification-dropdown';

        // Get notification data
        const notifications = this.getNotifications();

        if (notifications.length === 0) {
            dropdown.innerHTML = `
                <div class="notification-dropdown-header">
                    <h4>Notifications</h4>
                    <button class="notification-close" onclick="tracker.closeNotifications()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="notification-dropdown-content">
                    <div class="no-notifications">
                        <i class="fas fa-bell-slash"></i>
                        <p>No notifications</p>
                    </div>
                </div>
            `;
        } else {
            dropdown.innerHTML = `
                <div class="notification-dropdown-header">
                    <h4>Notifications</h4>
                    <button class="notification-close" onclick="tracker.closeNotifications()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="notification-dropdown-content">
                    ${notifications.map(notif => `
                        <div class="notification-item ${notif.unread ? 'unread' : ''}">
                            <div class="notification-icon" style="background-color: ${notif.color}20; color: ${notif.color};">
                                <i class="fas ${notif.icon}"></i>
                            </div>
                            <div class="notification-details">
                                <div class="notification-title">${notif.title}</div>
                                <div class="notification-message">${notif.message}</div>
                                <div class="notification-time">${notif.time}</div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        }

        // Position dropdown below notification button
        const notificationBtn = document.querySelector('.notification-btn');
        if (notificationBtn) {
            const rect = notificationBtn.getBoundingClientRect();
            dropdown.style.top = `${rect.bottom + 10}px`;
            dropdown.style.right = `${window.innerWidth - rect.right}px`;
        }

        document.body.appendChild(dropdown);
        dropdown.classList.add('active');
        this.updateNotificationBadge();
    }

    getNotifications() {
        const notifications = [];
        const totalExpenses = this.calculateTotalExpenses();
        const todayExpenses = this.calculateTodayExpenses();
        const weekExpenses = this.calculateWeekExpenses();

        // Budget alert
        if (totalExpenses > 0) {
            const avgDaily = totalExpenses / Math.max(1, this.expenses.length);
            if (todayExpenses > avgDaily * 1.5) {
                notifications.push({
                    icon: 'fa-exclamation-triangle',
                    title: 'Budget Alert',
                    message: `You've spent ${this.formatCurrency(todayExpenses)} today, which is above your average`,
                    time: 'Just now',
                    color: '#ef4444',
                    unread: true
                });
            }
        }

        // Weekly spending summary
        if (weekExpenses > 0) {
            notifications.push({
                icon: 'fa-chart-line',
                title: 'Weekly Summary',
                message: `Your spending this week: ${this.formatCurrency(weekExpenses)}`,
                time: '1 hour ago',
                color: '#3b82f6',
                unread: true
            });
        }

        // Recent expense added
        if (this.expenses.length > 0) {
            const recentExpense = this.expenses
                .sort((a, b) => new Date(b.date) - new Date(a.date))[0];
            const timeAgo = this.getRelativeTime(recentExpense.date);
            if (timeAgo.includes('minute') || timeAgo === 'Just now') {
                notifications.push({
                    icon: 'fa-check-circle',
                    title: 'Expense Added',
                    message: `${recentExpense.description} - ${this.formatCurrency(recentExpense.amount)}`,
                    time: timeAgo,
                    color: '#10b981',
                    unread: true
                });
            }
        }

        // Default notification if empty
        if (notifications.length === 0) {
            notifications.push({
                icon: 'fa-info-circle',
                title: 'Welcome!',
                message: 'Start tracking your expenses to receive notifications',
                time: 'Just now',
                color: '#8b5cf6',
                unread: false
            });
        }

        return notifications.slice(0, 5); // Limit to 5 notifications
    }

    updateNotificationBadge() {
        const badge = document.querySelector('.notification-badge');
        const notifications = this.getNotifications();
        const unreadCount = notifications.filter(n => n.unread).length;
        
        if (badge) {
            if (unreadCount > 0) {
                badge.textContent = unreadCount > 99 ? '99+' : unreadCount;
                badge.style.display = 'block';
            } else {
                badge.style.display = 'none';
            }
        }
    }

    // Utilities
    setCurrentDate() {
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('expenseDate').value = today;
    }

    formatCurrency(amount) {
        return '₹' + new Intl.NumberFormat('en-IN', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(amount);
    }

    formatDate(dateString) {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.textContent = message;
        
        // Add styles
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 1rem 1.5rem;
            background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
            color: white;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            z-index: 3000;
            animation: slideIn 0.3s ease;
        `;

        document.body.appendChild(notification);

        // Remove after 3 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }

    // Chart period update
    updateChartPeriod(period) {
        // Update chart based on selected period
        this.initExpenseTrendChart();
        this.showNotification(`Chart updated to ${period} view`, 'info');
    }

    // Support message functionality
    sendSupportMessage() {
        const input = document.querySelector('.support-input input');
        const message = input.value.trim();
        
        if (!message) return;

        // Add user message to chat
        const supportMessages = document.querySelector('.support-messages');
        const userMessageHtml = `
            <div class="support-message user-message">
                <div class="support-avatar">
                    <i class="fas fa-user"></i>
                </div>
                <div class="support-text">
                    <p>${this.escapeHtml(message)}</p>
                    <span class="support-time">You • Just now</span>
                </div>
            </div>
        `;
        
        supportMessages.insertAdjacentHTML('beforeend', userMessageHtml);
        input.value = '';
        supportMessages.scrollTop = supportMessages.scrollHeight;

        // Generate intelligent response
        setTimeout(() => {
            const response = this.generateChatbotResponse(message);
            const responseHtml = `
                <div class="support-message">
                    <div class="support-avatar">
                        <i class="fas fa-headset"></i>
                    </div>
                    <div class="support-text">
                        <p>${response}</p>
                        <span class="support-time">Support Team • Just now</span>
                    </div>
                </div>
            `;
            supportMessages.insertAdjacentHTML('beforeend', responseHtml);
            supportMessages.scrollTop = supportMessages.scrollHeight;
        }, 800);
    }

    // Generate intelligent chatbot response based on user message
    generateChatbotResponse(message) {
        const lowerMessage = message.toLowerCase().trim();
        
        // Early return for empty messages
        if (!lowerMessage) {
            return `Hello! How can I help you with your expense tracking today?`;
        }

        // Prioritize more specific keywords first to avoid generic matches
        
        // Questions about adding expenses (high priority, specific)
        if (lowerMessage.match(/\b(add|create|new|record|enter|insert|how to add|how do i add)\b.*\b(expense|spending|transaction)\b/i) ||
            lowerMessage.match(/\b(expense|spending|transaction)\b.*\b(add|create|new|record|enter|how)\b/i)) {
            return `To add an expense, click on "Add Expense" in the sidebar menu. Fill in the date, select a category (Food, Transport, Shopping, etc.), enter a description, and the amount. Click "Save Expense" to record it. Would you like me to guide you through adding a specific expense?`;
        }

        // Questions about viewing/managing expenses (high priority, specific)
        if (lowerMessage.match(/\b(view|see|show|list|display|check|look at|find|get)\b.*\b(expense|expenses|spending|transaction|transactions)\b/i) ||
            lowerMessage.match(/\b(all|my|manage|manage my)\b.*\b(expense|expenses)\b/i)) {
            return `You can view all your expenses by clicking "Manage Expenses" in the sidebar. There you can search, filter by category or date, edit, or delete expenses. You can also see recent transactions on the Dashboard. Need help with filtering or editing?`;
        }

        // Questions about today's expenses (specific check before general total)
        if (lowerMessage.match(/\b(today|today's|today\s+spending|spent today|today expense)\b/i)) {
            const todayTotal = this.calculateTodayExpenses();
            const todayExpenses = this.expenses.filter(expense => 
                new Date(expense.date).toDateString() === new Date().toDateString()
            );
            
            if (todayExpenses.length === 0) {
                return `You haven't recorded any expenses today. Your spending today is ₹0.00. Add an expense to start tracking!`;
            }
            
            const categoryBreakdown = this.getCategoryBreakdown(todayExpenses);
            return `Today you've spent ${this.formatCurrency(todayTotal)} across ${todayExpenses.length} transaction${todayExpenses.length !== 1 ? 's' : ''}. Breakdown: ${categoryBreakdown}. Check the Dashboard for more details!`;
        }

        // Questions about total expenses (check for specific keywords)
        if (lowerMessage.match(/\b(total|how much|how many|sum|amount|spent|spending|total expense|overall|all time)\b/i) && 
            !lowerMessage.match(/\b(today|yesterday|week|month|year)\b/i)) {
            const total = this.calculateTotalExpenses();
            const todayTotal = this.calculateTodayExpenses();
            const count = this.expenses.length;
            
            if (count === 0) {
                return `You haven't recorded any expenses yet. Your total expenses are ₹0.00. Start by adding your first expense using the "Add Expense" menu!`;
            }
            
            return `Your total expenses are ${this.formatCurrency(total)} across ${count} transaction${count !== 1 ? 's' : ''}. Today you've spent ${this.formatCurrency(todayTotal)}. You can see detailed breakdowns in the Reports section. Would you like to see expenses by category or date range?`;
        }

        // Questions about categories (specific)
        if (lowerMessage.match(/\b(category|categories|what category|which category|category list|available category)\b/i)) {
            const categories = this.getUniqueCategories();
            const categoryList = categories.length > 0 
                ? categories.join(', ') 
                : 'No categories used yet';
            
            return `Available categories are: Food, Transport, Shopping, Entertainment, Bills, Healthcare, Education, and Other. You've used: ${categoryList}. You can filter expenses by category in the "Manage Expenses" section.`;
        }

        // Questions about reports (specific)
        if (lowerMessage.match(/\b(report|reports|statistics|stats|analytics|analysis|chart|charts|graph|graphs|summary|summaries)\b/i)) {
            return `You can access various reports from the "Reports" menu in the sidebar:
• Expense Reports - Overview with charts
• Date-wise Reports - Filter by date range
• Month-wise Reports - View monthly spending
• Year-wise Reports - Annual summary

The Dashboard also shows expense trends and recent transactions. Which report would you like to explore?`;
        }

        // Questions about editing/deleting expenses (specific)
        if (lowerMessage.match(/\b(edit|change|update|modify|correct|fix)\b/i)) {
            return `To edit an expense, go to "Manage Expenses" in the sidebar. Find the expense you want to modify, then click the edit (pencil) icon to change it. You can update the date, category, description, or amount. You can also search and filter to find specific expenses quickly.`;
        }

        if (lowerMessage.match(/\b(delete|remove|erase|clear|get rid of)\b/i)) {
            return `To delete an expense, go to "Manage Expenses" in the sidebar. Find the expense you want to remove, then click the delete (trash) icon. You'll be asked to confirm before the expense is permanently deleted.`;
        }

        // Questions about budget (specific)
        if (lowerMessage.match(/\b(budget|limit|budget alert|over budget|budget warning|set budget)\b/i)) {
            const total = this.calculateTotalExpenses();
            return `Currently, there's no budget limit set in the system. Your total expenses are ${this.formatCurrency(total)}. You can track your spending patterns through the Reports section to help manage your budget. Would you like tips on budgeting?`;
        }

        // Questions about search/filter (specific)
        if (lowerMessage.match(/\b(search|find|locate|look for|filter|where is|where can i find)\b/i)) {
            return `You can search expenses in two ways:
1. Use the search bar at the top right to search across all expenses - results will appear in a popup
2. Go to "Manage Expenses" and use the search box, category filter, or date filter

You can search by description or category name. The search results will highlight matching terms!`;
        }

        // Questions about help/features (specific)
        if (lowerMessage.match(/\b(help|how|what can|features|what does|guide|tutorial|how does|instructions)\b/i)) {
            return `I can help you with:
• Adding and managing expenses
• Viewing spending summaries and totals
• Generating reports (date, month, year-wise)
• Understanding categories and filters
• Searching your expenses

What would you like to know more about? You can also explore the Dashboard, Add Expense, Manage Expenses, and Reports sections in the sidebar.`;
        }

        // Questions about the app/account (specific)
        if (lowerMessage.match(/\b(account|profile|user|my info|my account|settings|logout|sign out|log out)\b/i)) {
            return `Your account information is displayed in the sidebar. You can see your name and email there. To logout, click the logout icon (sign-out) in the sidebar header. Your expenses are saved securely in your browser's local storage.`;
        }

        // Questions about week/month/year expenses
        if (lowerMessage.match(/\b(this week|weekly|week|last week)\b/i)) {
            const weekExpenses = this.calculateWeekExpenses();
            return `Your spending this week is ${this.formatCurrency(weekExpenses)}. You can see weekly breakdowns in the Reports section under "Month-wise Reports" or check the Dashboard charts.`;
        }

        if (lowerMessage.match(/\b(this month|monthly|month|last month)\b/i)) {
            const month = new Date().getMonth();
            const year = new Date().getFullYear();
            const monthExpenses = this.expenses
                .filter(expense => {
                    const expDate = new Date(expense.date);
                    return expDate.getMonth() === month && expDate.getFullYear() === year;
                })
                .reduce((total, expense) => total + parseFloat(expense.amount), 0);
            return `Your spending this month is ${this.formatCurrency(monthExpenses)}. Check the "Month-wise Reports" section for detailed monthly analysis.`;
        }

        // Greetings (check early but after specific queries)
        if (lowerMessage.match(/\b(hello|hi|hey|greetings|good morning|good afternoon|good evening|good night)\b/i)) {
            const total = this.calculateTotalExpenses();
            const count = this.expenses.length;
            return `Hello! I'm here to help you with your expense tracking. You have ${count} expense${count !== 1 ? 's' : ''} recorded, totaling ${this.formatCurrency(total)}. How can I assist you today?`;
        }

        // Thank you responses
        if (lowerMessage.match(/\b(thank|thanks|appreciate|helpful|great|awesome|nice)\b/i)) {
            return `You're welcome! I'm glad I could help. If you have any other questions about tracking your expenses, feel free to ask. Happy expense tracking! 💰`;
        }

        // Questions with question words (try to provide contextual help)
        if (lowerMessage.match(/^(what|where|when|why|how|which|who|can|do|does|is|are|will|would)\b/i)) {
            return `I can help you with various expense tracking questions. Here are some things you can ask:
• "How do I add an expense?"
• "What are my total expenses?"
• "Show me today's spending"
• "How do I view reports?"
• "How do I search for expenses?"

Could you rephrase your question? For example: "${message.replace(/^(what|where|when|why|how|which|who|can|do|does|is|are|will|would)\b/i, '')}"`;
        }

        // Default response for unrecognized queries (make it more helpful)
        const suggestions = [
            'Try asking "How do I add an expense?"',
            'Try asking "What are my total expenses?"',
            'Try asking "Show me today\'s spending"',
            'Try asking "How do I view reports?"'
        ];
        const randomSuggestion = suggestions[Math.floor(Math.random() * suggestions.length)];
        
        return `I'm not sure I understand "${message}". ${randomSuggestion}. I can help you with adding expenses, viewing reports, searching expenses, and managing your spending. What would you like to know?`;
    }

    // Helper function to check if message matches keywords
    matchesKeywords(message, keywords) {
        return keywords.some(keyword => message.includes(keyword));
    }

    // Helper function to escape HTML
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Helper function to get category breakdown
    getCategoryBreakdown(expenses) {
        const categoryData = {};
        expenses.forEach(expense => {
            categoryData[expense.category] = (categoryData[expense.category] || 0) + parseFloat(expense.amount);
        });
        
        return Object.entries(categoryData)
            .map(([category, amount]) => `${category}: ${this.formatCurrency(amount)}`)
            .join(', ') || 'No categories';
    }
}

// Add animation styles
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .btn-sm {
        padding: 0.375rem 0.75rem;
        font-size: 0.875rem;
    }
`;
document.head.appendChild(style);

// Initialize the app
const tracker = new ExpenseTracker();

// Make functions globally accessible
window.tracker = tracker;
window.closeEditModal = () => tracker.closeEditModal();
window.generateDateReport = () => tracker.generateDateReport();
window.generateMonthReport = () => tracker.generateMonthReport();
window.generateYearReport = () => tracker.generateYearReport();

// Add sample expenses for testing (only if no expenses exist)
setTimeout(() => {
    if (tracker.expenses.length === 0 && tracker.currentUser) {
        const sampleExpenses = [
            {
                id: '1',
                date: new Date().toISOString(),
                category: 'Food',
                description: 'Grocery shopping',
                amount: 85.50,
                userId: tracker.currentUser.id
            },
            {
                id: '2', 
                date: new Date(Date.now() - 86400000).toISOString(),
                category: 'Transport',
                description: 'Gas refill',
                amount: 45.00,
                userId: tracker.currentUser.id
            },
            {
                id: '3',
                date: new Date(Date.now() - 172800000).toISOString(),
                category: 'Entertainment',
                description: 'Movie tickets',
                amount: 25.00,
                userId: tracker.currentUser.id
            }
        ];
        
        tracker.expenses = sampleExpenses;
        tracker.saveExpenses();
        tracker.updateDashboard();
        tracker.showNotification('Sample expenses added for demonstration', 'success');
    }
}, 1000);

